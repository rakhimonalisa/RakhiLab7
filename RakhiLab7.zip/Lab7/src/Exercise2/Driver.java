
package Exercise2;

public class Driver {
	
	public static void main(String[] args) {
int[] array1 = {55, 64, 53, 89, 11, 22, 45, 32, 67, 54, 32};
		
		System.out.println("Before Sort\n");
		for(int i: array1) {
			System.out.print(i+" ");
		}
		System.out.println("\n*****************************************************************************");
		MergeSort mergeSortArray = new MergeSort();
		mergeSortArray.sort(array1);
		
		System.out.println("After Sort\n");
		for(int i: array1) {
			System.out.print(i+" ");
		}
	}

}
